export const errorMessages = {
  required: "This field is required",
  validEmail: "Please enter a valid email address",
};
