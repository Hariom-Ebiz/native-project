import React from "react";


const Authentication = ({ data, children }) => {
  return <>{children}</>;
};

export default Authentication;
