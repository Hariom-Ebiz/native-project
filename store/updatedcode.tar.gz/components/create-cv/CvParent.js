import JobSeekerAuth from "@/components/layout/JobSeekerAuth";
import Topbar from "@/components/jobSeeker/Topbar";

import styles from "@/styles/edit_cv_steps.module.css";

const CvParent = ({ children }) => {
  return (
    <JobSeekerAuth data={{ title: "Edit CV" }}>
      <div className="page_container">
        <div className="main_content main_bg">
          <div className={styles.step_wrapper}>
            <Topbar />
          </div>
          {children}
        </div>
      </div>
    </JobSeekerAuth>
  );
};

export default CvParent;
