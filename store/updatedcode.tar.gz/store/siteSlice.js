import { createSlice } from "@reduxjs/toolkit";

const siteSlice = createSlice({
  name: "site",
  initialState: {
    setting: {},
    loading: true,
    modalOpen: false,
    modalData: "",
    isMobileSidebarOpen: false,
  },
  reducers: {
    updateSetting: (state, action) => {
      state.setting = action.payload;
    },
    updateLoading: (state, action) => {
      state.loading = action.payload;
    },
    setModal: (state, action) => {
      state.modalOpen = true;
      state.modalData = action.payload;
    },
    unsetModal: (state, action) => {
      state.modalOpen = false;
      state.modalData = "";
    },
    openAuthSidebar: (state, action) => {
      state.isMobileSidebarOpen = action.payload;
    },
  },
});

export const {
  updateSetting,
  updateLoading,
  setModal,
  unsetModal,
  openAuthSidebar,
} = siteSlice.actions;
export default siteSlice.reducer;
