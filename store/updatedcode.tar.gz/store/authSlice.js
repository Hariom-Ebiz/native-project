import { createSlice } from "@reduxjs/toolkit";
import { destroyCookie, setCookie } from "nookies";

const siteSlice = createSlice({
  name: "auth",
  initialState: {
    loggedIn: null,
    token: null,
    userId: null,
    email: null,
    firstName: null,
    lastName: null,
    profilePic: null,
    role: null,
  },
  reducers: {
    logout: (state, action) => {
      localStorage.removeItem("authToken");
      destroyCookie(null, "token");
      state.loggedIn = false;
      state.token = null;
      state.userId = null;
      state.email = null;
      state.firstName = null;
      state.lastName = null;
      state.profilePic = null;
      state.cvStep = null;
    },
    login: (state, action) => {
      let {
        token,
        userId,
        email,
        firstName,
        lastName,
        profilePic,
        role,
        cvStep,
      } = action.payload;
      localStorage.setItem("authToken", JSON.stringify(token));
      setCookie(null, "token", token, {
        maxAge: 30 * 24 * 60 * 60 * 100,
        path: "/",
        // sameSite: "None",
        // secure: true,
      });

      state.loggedIn = true;
      state.token = token;
      state.userId = userId;
      state.email = email;
      state.firstName = firstName;
      state.lastName = lastName;
      state.profilePic = profilePic;
      state.role = role;
      state.cvStep = cvStep;
    },
    update: (state, action) => {
      let { firstName, lastName, profilePic } = action.payload;
      state.firstName = firstName;
      state.lastName = lastName;
      state.profilePic = profilePic;
    },
    updateCvStep: (state, action) => {
      state.cvStep = action.payload;
    },    
  },
});

export const { logout, login, update, updateCvStep, updateLoading } = siteSlice.actions;
export default siteSlice.reducer;
