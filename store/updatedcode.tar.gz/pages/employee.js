import PublicLayout from "@/components/layout/PublicLayout";
import React from "react";

const Employee = () => {
  return (
    <>
    <PublicLayout>
      <div className="coming_soon_block">“Stay Tuned! Coming Soon”</div>
      </PublicLayout>
    </>
  );
};

export default Employee;
