import { axiosInstance } from "../api";

export const getHomePageData = async (slug) => {
  let res , res1
  try {
    res = await axiosInstance.get("block/get-block/home-page");
    res1 = await axiosInstance.get("master/testimonials");

  } catch (err) {
    return {
      homePageBlocks: {},
      testimonials: {},
    };
  }
  return {
    homePageBlocks: res?.data?.blocks || {},
    testimonials: res1?.data?.list || {},
  };
};

export const getEmployerPageData = async (slug) => {
  let res
  try {
    res = await axiosInstance.get("block/get-block/employer-page");
  } catch (err) {
    return {
      employerPageBlocks: {},
    };
  }
  return {
    employerPageBlocks: res?.data?.blocks || {},
  };
};

export const getContactUsData = async (slug) => {
  let res;
  try {
    res = await axiosInstance.get("block/get-block/contactus-page");
  } catch (err) {
    return {
      contactPageBlocks: {},
    };
  }
  return {
    contactPageBlocks: res?.data?.blocks || {},
  };
};

export const getAboutUsPageData = async (slug) => {
  let res;
  try {
    res = await axiosInstance.get("cms/slug/about-us");
  } catch (err) {
    return {
      aboutUsPageBlocks: {},
    };
  }
  return {
    aboutUsPageBlocks: res?.data?.cms || {},
  };
};

export const getTermAndConditionsPageData = async (slug) => {
  let res;
  try {
    res = await axiosInstance.get("cms/slug/terms-and-conditions");
  } catch (err) {
    console.log("something went wrong");
    return {
      termAndConditionsPageBlocks: {},
    };
  }
  //console.log("response>>>>", res);
  return {
    termAndConditionsPageBlocks: res?.data?.cms || {},
  };
};

export const getPrivacyPolicyPageData = async (slug) => {
  let res;
  try {
    res = await axiosInstance.get("cms/slug/privacy-policy");
  } catch (err) {
    console.log("something went wrong");
    return {
      privacyPolicyPageBlocks: {},
    };
  }
  //  console.log("response>>>>", res);
  return {
    privacyPolicyPageBlocks: res?.data?.cms || {},
  };
};


