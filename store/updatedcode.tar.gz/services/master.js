import { axiosInstance } from "@/api";

export const getMasters = async (type) => {
  let res;
  try {
    res = await axiosInstance.get(`master/all?type=${type}`);
  } catch (err) {
    return {
      masters: [],
      totalDocuments: 0,
    };
  }
  return { masters: res.data.records, totalDocuments: res.data.totalRecords };
};

export const getOne = async (id) => {
  let res;

  try {
    res = await axiosInstance.get(`master/${id}`);
  } catch (err) {
    return {};
  }

  return res.data.master;
};
